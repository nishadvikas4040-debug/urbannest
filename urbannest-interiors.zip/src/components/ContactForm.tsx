import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    city: '',
    projectType: '',
    budget: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormData({ fullName: '', phone: '', email: '', city: '', projectType: '', budget: '', message: '' });
      setTimeout(() => setIsSubmitted(false), 5000);
    }, 1500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section id="contact" className="py-24 bg-background-warm relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col lg:flex-row">
          
          {/* Contact Information Panel */}
          <div className="bg-primary text-white p-12 lg:w-2/5 flex flex-col justify-between">
            <div>
              <h3 className="font-serif text-3xl font-bold mb-4">Get in Touch</h3>
              <p className="text-secondary/90 mb-12">
                Ready to transform your space? Fill out the form, and our design team will get back to you shortly.
              </p>

              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <Phone className="w-6 h-6 text-secondary shrink-0 mt-1" />
                  <div>
                    <h4 className="font-medium text-sm text-secondary uppercase tracking-wider mb-1">Phone</h4>
                    <a href="tel:+919876543210" className="text-lg hover:underline">+91 98765 43210</a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Mail className="w-6 h-6 text-secondary shrink-0 mt-1" />
                  <div>
                    <h4 className="font-medium text-sm text-secondary uppercase tracking-wider mb-1">Email</h4>
                    <a href="mailto:info@urbannestinteriors.in" className="text-lg hover:underline break-all">info@urbannestinteriors.in</a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <MapPin className="w-6 h-6 text-secondary shrink-0 mt-1" />
                  <div>
                    <h4 className="font-medium text-sm text-secondary uppercase tracking-wider mb-1">Address</h4>
                    <p className="text-lg leading-relaxed">
                      301, Shree Hari Business Hub,<br />
                      SG Highway,<br />
                      Ahmedabad, Gujarat – 380015,<br />
                      India
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <Clock className="w-6 h-6 text-secondary shrink-0 mt-1" />
                  <div>
                    <h4 className="font-medium text-sm text-secondary uppercase tracking-wider mb-1">Business Hours</h4>
                    <p className="text-lg">Monday – Saturday: 9:00 AM – 7:00 PM</p>
                    <p className="text-white/80">Sunday: Closed</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Form Panel */}
          <div className="p-12 lg:w-3/5 bg-white">
            <h3 className="font-serif text-3xl font-bold text-gray-900 mb-8">Request a Quote</h3>
            
            {isSubmitted ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-green-50 text-green-800 p-8 rounded-2xl text-center border border-green-100"
              >
                <div className="w-16 h-16 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <h4 className="text-2xl font-bold mb-2">Thank You!</h4>
                <p>We've received your request and will contact you within 24 hours.</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                    <input required type="text" id="fullName" name="fullName" value={formData.fullName} onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-shadow" 
                      placeholder="John Doe" />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                    <input required type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-shadow" 
                      placeholder="+91 XXXXX XXXXX" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <input required type="email" id="email" name="email" value={formData.email} onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-shadow" 
                      placeholder="john@example.com" />
                  </div>
                  <div>
                    <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-2">City</label>
                    <input required type="text" id="city" name="city" value={formData.city} onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-shadow" 
                      placeholder="Ahmedabad" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="projectType" className="block text-sm font-medium text-gray-700 mb-2">Type of Project</label>
                    <select required id="projectType" name="projectType" value={formData.projectType} onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-shadow bg-white text-black">
                      <option value="" disabled>Select project type</option>
                      <option value="Residential">Residential Interior</option>
                      <option value="Commercial">Commercial Interior</option>
                      <option value="Renovation">Home Renovation</option>
                      <option value="Modular Kitchen">Modular Kitchen</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="budget" className="block text-sm font-medium text-gray-700 mb-2">Budget Range</label>
                    <select required id="budget" name="budget" value={formData.budget} onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-shadow bg-white text-black">
                      <option value="" disabled>Select budget</option>
                      <option value="Under 5L">Under ₹5 Lakhs</option>
                      <option value="5L - 10L">₹5L - ₹10 Lakhs</option>
                      <option value="10L - 25L">₹10L - ₹25 Lakhs</option>
                      <option value="Above 25L">Above ₹25 Lakhs</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <textarea required id="message" name="message" rows={4} value={formData.message} onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-shadow resize-none" 
                    placeholder="Tell us about your project requirements..." />
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-gray-900 text-white font-medium py-4 rounded-lg hover:bg-gray-800 transition-colors flex justify-center items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                  ) : 'Submit Request'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
