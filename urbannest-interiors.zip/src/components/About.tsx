import { CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function About() {
  const highlights = [
    'Tailored Residential Designs',
    'Functional Commercial Spaces',
    'End-to-End Renovation',
    'Custom Furniture Solutions',
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          
          {/* Image Side */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl relative z-10">
              <img 
                src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                alt="Modern interior design work"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Decorative block */}
            <div className="absolute -bottom-8 -left-8 w-64 h-64 bg-secondary/30 rounded-full blur-3xl z-0"></div>
          </motion.div>

          {/* Text Side */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Designing Spaces that Tell Your Story
            </h2>
            <div className="w-20 h-1 bg-primary mb-8 rounded-full"></div>
            
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              <strong>UrbanNest Interiors</strong> specializes in residential and commercial interior design services. We provide modular kitchens, bedroom designs, living room renovations, office interiors, and custom furniture solutions. 
            </p>
            <p className="text-lg text-gray-600 mb-10 leading-relaxed">
              Our team focuses on creating functional and aesthetically pleasing spaces tailored to each client's unique needs and lifestyle preferences. From concept to completion, we manage every detail.
            </p>

            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {highlights.map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-primary shrink-0" />
                  <span className="text-gray-800 font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
