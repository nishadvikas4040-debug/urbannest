import { ChefHat, Sofa, Bed, DoorOpen, Briefcase, Store, Coffee, PaintRoller, LayoutPanelTop, Zap, Layers } from 'lucide-react';
import { motion } from 'motion/react';
import { services } from '../data';

// Custom Icon mapping component to safely map strings to Lucide icons
const IconRenderer = ({ name, className }: { name: string; className?: string }) => {
  const icons: Record<string, any> = {
    'chef-hat': ChefHat,
    'sofa': Sofa,
    'bed': Bed,
    'door-open': DoorOpen,
    'briefcase': Briefcase,
    'store': Store,
    'coffee': Coffee,
    'paint-roller': PaintRoller,
    'layout-panel-top': LayoutPanelTop,
    'zap': Zap,
    'layers': Layers,
  };
  
  const Icon = icons[name] || layers;
  return <Icon className={className} />;
};

export default function Services() {
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section id="services" className="py-24 bg-background-warm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-6">Our Expertise</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6 rounded-full"></div>
          <p className="text-lg text-gray-600">
            Comprehensive design and renovation solutions for every space.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Residential */}
          <motion.div variants={containerVariants} initial="hidden" whileInView="show" viewport={{ once: true }}>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 h-full hover:shadow-md transition-shadow">
              <h3 className="font-serif text-2xl font-bold text-gray-900 mb-8 pb-4 border-b border-gray-100 flex items-center gap-3">
                <Sofa className="text-primary h-8 w-8" /> Residential
              </h3>
              <ul className="space-y-6">
                {services.residential.map((service, idx) => (
                  <motion.li key={idx} variants={itemVariants} className="flex items-center gap-4 group">
                    <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                      <IconRenderer name={service.icon} className="w-5 h-5" />
                    </div>
                    <span className="text-gray-700 font-medium text-lg">{service.name}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Commercial */}
          <motion.div variants={containerVariants} initial="hidden" whileInView="show" viewport={{ once: true }}>
            <div className="bg-primary p-8 rounded-2xl shadow-lg h-full text-white transform lg:-translate-y-4">
              <h3 className="font-serif text-2xl font-bold mb-8 pb-4 border-b border-white/20 flex items-center gap-3">
                <Briefcase className="text-secondary h-8 w-8" /> Commercial
              </h3>
              <ul className="space-y-6">
                {services.commercial.map((service, idx) => (
                  <motion.li key={idx} variants={itemVariants} className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-secondary">
                      <IconRenderer name={service.icon} className="w-5 h-5" />
                    </div>
                    <span className="font-medium text-lg text-gray-50">{service.name}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Renovation */}
          <motion.div variants={containerVariants} initial="hidden" whileInView="show" viewport={{ once: true }}>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 h-full hover:shadow-md transition-shadow">
              <h3 className="font-serif text-2xl font-bold text-gray-900 mb-8 pb-4 border-b border-gray-100 flex items-center gap-3">
                <PaintRoller className="text-primary h-8 w-8" /> Renovation
              </h3>
              <ul className="space-y-6">
                {services.renovation.map((service, idx) => (
                  <motion.li key={idx} variants={itemVariants} className="flex items-center gap-4 group">
                    <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                      <IconRenderer name={service.icon} className="w-5 h-5" />
                    </div>
                    <span className="text-gray-700 font-medium text-lg">{service.name}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
