export const services = {
  residential: [
    { name: 'Modular Kitchens', icon: 'chef-hat' },
    { name: 'Living Room Design', icon: 'sofa' },
    { name: 'Bedroom Interiors', icon: 'bed' },
    { name: 'Wardrobe Solutions', icon: 'door-open' },
  ],
  commercial: [
    { name: 'Office Interiors', icon: 'briefcase' },
    { name: 'Retail Store Design', icon: 'store' },
    { name: 'Café and Restaurant Interiors', icon: 'coffee' },
  ],
  renovation: [
    { name: 'Painting', icon: 'paint-roller' },
    { name: 'False Ceiling', icon: 'layout-panel-top' },
    { name: 'Electrical Work', icon: 'zap' },
    { name: 'Flooring Solutions', icon: 'layers' },
  ],
};

export const testimonials = [
  {
    name: 'Rahul Mehta',
    location: 'Ahmedabad',
    quote: "UrbanNest Interiors transformed our apartment beautifully. Their team was professional and delivered on time.",
  },
  {
    name: 'Priya Shah',
    location: 'Surat',
    quote: "Excellent service and attention to detail. Highly recommended for home renovations.",
  },
];
